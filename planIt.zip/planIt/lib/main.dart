import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'dart:async'; // Import for Timer

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Todo List App',
      theme: ThemeData(
        primarySwatch: Colors.purple,
        appBarTheme: AppBarTheme(
          backgroundColor: Colors.purple,
        ),
        floatingActionButtonTheme: FloatingActionButtonThemeData(
          backgroundColor: Colors.purple,
        ),
        buttonTheme: ButtonThemeData(
          buttonColor: Colors.purple,
        ),
        textButtonTheme: TextButtonThemeData(
          style: ButtonStyle(
            foregroundColor: MaterialStateProperty.all<Color>(Colors.purple),
          ),
        ),
      ),
      home: SplashScreen(), // Set the splash screen as the initial screen
    );
  }
}

class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Timer(Duration(seconds: 4), () {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => LoginPage()),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.purple,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset('assets/todologo.png', width: 300, height: 300),
            SizedBox(height: 20),
            Text(
              'Welcome to PlanIt APP',
              style: TextStyle(fontSize: 24, color: Colors.white),
            ),
          ],
        ),
      ),
    );
  }
}

class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _formKey = GlobalKey<FormState>();
  final _usernameController = TextEditingController();
  final _passwordController = TextEditingController();
  final _createUsernameController = TextEditingController();
  final _createPasswordController = TextEditingController();
  String? _errorMessage;
  bool _isCreatingAccount = false;
  Map<String, String> _userAccounts =
  {}; // Simple in-memory storage for usernames and passwords

  void _login() {
    final username = _usernameController.text;
    final password = _passwordController.text;

    if (_userAccounts.containsKey(username) &&
        _userAccounts[username] == password) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => TodoList()),
      );
    } else {
      setState(() {
        _errorMessage = 'Login failed';
      });
    }
  }

  void _createAccount() {
    final username = _createUsernameController.text;
    final password = _createPasswordController.text;

    if (username.isNotEmpty && password.isNotEmpty) {
      setState(() {
        _userAccounts[username] = password;
        _errorMessage = 'Account created successfully. You can now log in.';
        _isCreatingAccount = false;
      });
    } else {
      setState(() {
        _errorMessage = 'Please enter a username and password';
      });
    }
  }

  @override
  void dispose() {
    _usernameController.dispose();
    _passwordController.dispose();
    _createUsernameController.dispose();
    _createPasswordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Login'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child:
        _isCreatingAccount ? _buildCreateAccountForm() : _buildLoginForm(),
      ),
    );
  }

  Widget _buildLoginForm() {
    return Form(
      key: _formKey,
      child: Column(
        children: [
          TextFormField(
            controller: _usernameController,
            decoration: InputDecoration(labelText: 'Username'),
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'Please enter your username';
              }
              return null;
            },
          ),
          SizedBox(height: 16),
          TextFormField(
            controller: _passwordController,
            decoration: InputDecoration(labelText: 'Password'),
            obscureText: true,
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'Please enter your password';
              }
              return null;
            },
          ),
          SizedBox(height: 16),
          ElevatedButton(
            onPressed: _login,
            child: Text('Login'),
          ),
          SizedBox(height: 16),
          TextButton(
            onPressed: () {
              setState(() {
                _isCreatingAccount = true;
              });
            },
            child: Text('Create New Account'),
          ),
          if (_errorMessage != null)
            Padding(
              padding: const EdgeInsets.only(top: 16.0),
              child: Text(
                _errorMessage!,
                style: TextStyle(color: Colors.red),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildCreateAccountForm() {
    return Form(
      key: _formKey,
      child: Column(
        children: [
          TextFormField(
            controller: _createUsernameController,
            decoration: InputDecoration(labelText: 'New Username'),
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'Please enter a username';
              }
              return null;
            },
          ),
          SizedBox(height: 16),
          TextFormField(
            controller: _createPasswordController,
            decoration: InputDecoration(labelText: 'New Password'),
            obscureText: true,
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'Please enter a password';
              }
              return null;
            },
          ),
          SizedBox(height: 16),
          ElevatedButton(
            onPressed: _createAccount,
            child: Text('Create Account'),
          ),
          SizedBox(height: 16),
          TextButton(
            onPressed: () {
              setState(() {
                _isCreatingAccount = false;
              });
            },
            child: Text('Back to Login'),
          ),
          if (_errorMessage != null)
            Padding(
              padding: const EdgeInsets.only(top: 16.0),
              child: Text(
                _errorMessage!,
                style: TextStyle(color: Colors.red),
              ),
            ),
        ],
      ),
    );
  }
}

class TodoList extends StatefulWidget {
  @override
  _TodoListState createState() => _TodoListState();
}

class _TodoListState extends State<TodoList>
    with SingleTickerProviderStateMixin {
  Map<String, List<TodoItem>> _pendingItems = {
    'Grocery': [],
    'Fitness': [],
    'Appointments': [],
    'Skincare': [],
    'Project': [],
    'Personal': [],
    'Education': [],
    'Shopping': [],
  };

  Map<String, List<TodoItem>> _completedItems = {
    'Grocery': [],
    'Fitness': [],
    'Appointments': [],
    'Skincare': [],
    'Project': [],
    'Personal': [],
    'Education': [],
    'Shopping': [],
  };

  final _titleController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _deadlineController = TextEditingController();
  String _selectedUrgency = 'Medium';
  String _selectedCategory = 'Grocery';

  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _titleController.dispose();
    _descriptionController.dispose();
    _deadlineController.dispose();
    _tabController.dispose();
    super.dispose();
  }

  void _addTodoItem(String title, String description, DateTime deadline,
      String urgency, String category) {
    setState(() {
      final newItem = TodoItem(title, description, deadline, urgency, false);
      _pendingItems[category]?.add(newItem);
    });
  }

  void _removeTodoItem(TodoItem item, String category) {
    setState(() {
      if (item.isCompleted) {
        _completedItems[category]?.remove(item);
      } else {
        _pendingItems[category]?.remove(item);
      }
    });
  }

  void _completeTodoItem(int index, String category) {
    setState(() {
      final item = _pendingItems[category]![index];
      _pendingItems[category]!.removeAt(index);
      item.isCompleted = true;
      _completedItems[category]?.add(item);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Todo List'),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(builder: (context) => LoginPage()),
                  (route) => false, // Remove all previous routes
            );
          },
        ),
        bottom: TabBar(
          controller: _tabController,
          tabs: [
            Tab(text: 'Pending'),
            Tab(text: 'Completed'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildTodoListView('Pending'),
          _buildTodoListView('Completed'),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _showAddTodoDialog,
        child: Icon(Icons.add),
      ),
    );
  }

  void _showAddTodoDialog() {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Add Todo Item'),
          content: StatefulBuilder(
            builder: (BuildContext context, StateSetter setState) {
              return SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    TextField(
                      decoration: InputDecoration(labelText: 'Title'),
                      controller: _titleController,
                    ),
                    SizedBox(height: 16),
                    TextField(
                      decoration: InputDecoration(labelText: 'Description'),
                      controller: _descriptionController,
                    ),
                    SizedBox(height: 16),
                    DropdownButtonFormField<String>(
                      value: _selectedCategory,
                      items: _pendingItems.keys.map((String category) {
                        return DropdownMenuItem(
                          value: category,
                          child: Text(category),
                        );
                      }).toList(),
                      onChanged: (value) {
                        setState(() {
                          _selectedCategory = value!;
                        });
                      },
                      decoration: InputDecoration(labelText: 'Category'),
                    ),
                    SizedBox(height: 16),
                    DropdownButtonFormField<String>(
                      value: _selectedUrgency,
                      items: ['High', 'Medium', 'Low'].map((String urgency) {
                        return DropdownMenuItem(
                          value: urgency,
                          child: Text(urgency),
                        );
                      }).toList(),
                      onChanged: (value) {
                        setState(() {
                          _selectedUrgency = value!;
                        });
                      },
                      decoration: InputDecoration(labelText: 'Urgency'),
                    ),
                    SizedBox(height: 16),
                    ElevatedButton(
                      child: Text('Select Deadline'),
                      onPressed: () async {
                        final date = await showDatePicker(
                          context: context,
                          initialDate: DateTime.now(),
                          firstDate: DateTime(2022),
                          lastDate: DateTime(2030),
                        );
                        if (date != null) {
                          setState(() {
                            _deadlineController.text =
                                DateFormat('yyyy-MM-dd').format(date);
                          });
                        }
                      },
                    ),
                    SizedBox(height: 16),
                    ElevatedButton(
                      child: Text('Add Todo Item'),
                      onPressed: () {
                        if (_titleController.text.isNotEmpty &&
                            _descriptionController.text.isNotEmpty &&
                            _deadlineController.text.isNotEmpty) {
                          _addTodoItem(
                            _titleController.text,
                            _descriptionController.text,
                            DateTime.parse(_deadlineController.text),
                            _selectedUrgency,
                            _selectedCategory,
                          );
                          Navigator.of(context).pop();
                          _titleController.clear();
                          _descriptionController.clear();
                          _deadlineController.clear();
                          _selectedUrgency = 'Medium';
                          _selectedCategory = 'Grocery';
                        }
                      },
                    ),
                  ],
                ),
              );
            },
          ),
        );
      },
    );
  }

  Widget _buildTodoListView(String status) {
    return ListView(
      children: [
        _buildTodoList('Grocery', status),
        _buildTodoList('Fitness', status),
        _buildTodoList('Appointments', status),
        _buildTodoList('Skincare', status),
        _buildTodoList('Project', status),
        _buildTodoList('Personal', status),
        _buildTodoList('Education', status),
        _buildTodoList('Shopping', status),
      ],
    );
  }

  Widget _buildTodoList(String category, String status) {
    final items = status == 'Pending'
        ? _pendingItems[category]
        : _completedItems[category];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Text(
            category,
            style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.purple),
          ),
        ),
        ListView.builder(
          shrinkWrap: true,
          physics: NeverScrollableScrollPhysics(),
          itemCount: items?.length ?? 0,
          itemBuilder: (context, index) {
            final item = items![index];
            return Dismissible(
              key: Key(item.title),
              direction: DismissDirection.startToEnd,
              onDismissed: (direction) {
                _removeTodoItem(item, category);
              },
              background: Container(
                color: Colors.purple.shade200,
                alignment: Alignment.centerLeft,
                padding: EdgeInsets.symmetric(horizontal: 20),
                child: Icon(Icons.delete, color: Colors.white, size: 40),
              ),
              child: ListTile(
                title: Text(
                  item.title,
                  style: TextStyle(
                    decoration:
                    item.isCompleted ? TextDecoration.lineThrough : null,
                  ),
                ),
                subtitle: Text(
                  '${item.description}\nDeadline: ${DateFormat('yyyy-MM-dd').format(item.deadline)}\nUrgency: ${item.urgency}',
                  style: TextStyle(
                    decoration:
                    item.isCompleted ? TextDecoration.lineThrough : null,
                  ),
                ),
                trailing: status == 'Completed'
                    ? null
                    : IconButton(
                  icon: Icon(Icons.check, color: Colors.purple),
                  onPressed: () {
                    _completeTodoItem(index, category);
                  },
                ),
              ),
            );
          },
        ),
      ],
    );
  }
}

class TodoItem {
  String title;
  String description;
  DateTime deadline;
  String urgency;
  bool isCompleted;

  TodoItem(this.title, this.description, this.deadline, this.urgency,
      this.isCompleted);
}
